package com.guang.app.activity;

import android.support.v7.app.AppCompatActivity;

/**
 * Created by xiaoguang on 2017/2/13.
 */
public class BaseActivity extends AppCompatActivity {
}
