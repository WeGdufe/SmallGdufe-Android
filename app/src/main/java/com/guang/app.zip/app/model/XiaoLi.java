package com.guang.app.model;

/**
 * Created by xiaoguang on 2017/2/18.
 */
public class XiaoLi {
    /**
     * timeTable : http://jwc.gdufe.edu.cn/attach/2016/10/20/769667.jpg
     * xiaoLi : http://jwc.gdufe.edu.cn/attach/2016/10/20/769666.jpg
     */
    private String timeTable;
    private String xiaoLi;

    public String getTimeTable() {
        return timeTable;
    }

    public void setTimeTable(String timeTable) {
        this.timeTable = timeTable;
    }

    public String getXiaoLi() {
        return xiaoLi;
    }

    public void setXiaoLi(String xiaoLi) {
        this.xiaoLi = xiaoLi;
    }
}

