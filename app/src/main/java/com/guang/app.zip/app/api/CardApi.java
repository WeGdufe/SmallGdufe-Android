package com.guang.app.api;

/**
 * Created by xiaoguang on 2017/2/14.
 * 注意导入 import io.reactivex.Observable;
 */
public interface CardApi {
//    @GET(AppConfig.Url.yesterdayBalance)
//    Observable<HttpResult< String >> getYesterdayBalance();

}